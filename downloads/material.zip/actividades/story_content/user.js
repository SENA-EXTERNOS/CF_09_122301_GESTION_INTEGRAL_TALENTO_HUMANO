function ExecuteScript(strId)
{
  switch (strId)
  {
      case "68jGyIXLrzy":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

